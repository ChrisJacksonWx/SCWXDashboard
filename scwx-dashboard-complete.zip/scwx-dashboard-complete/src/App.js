import React from 'react';
import WinterWeatherOpsDashboard from './WinterWeatherOpsDashboard';
import './App.css';

function App() {
  return <WinterWeatherOpsDashboard />;
}

export default App;
